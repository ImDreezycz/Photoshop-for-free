DRZ = {}

DRZ.Loc = {
    
    BlipLocation = {
        {x = -1600.08, y = -1176.98, z = 1.51},
    }
}
DRZ.PedLocation = vector4(-1600.08, -1176.98, 0.51, 300.47) --TARGET
DRZ.Menu = vector4(-1600.08, -1176.98, 1.51, 0.88) --TARGET
DRZ.SpawnBoat = vector4(-1630.47, -1191.95, 0.12, 104.88) --SPAWN BOAT

DRZ.Seashark = "seashark" --SEASHARK MODEL
DRZ.Boat = "dinghy2" --BOAT MODEL
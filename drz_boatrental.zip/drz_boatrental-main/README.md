## ⚓Boat Rental⚓

# **Features:**
- Easy config edit
- Editable
- Lua
- Target system

# **Dependencies:**
- Framework: ESX
- Ox_target || (https://overextended.dev/ox_target) ||
- Ox_lib || (https://overextended.dev/ox_lib) ||

**DISCORD:** https://discord.gg/hfmADm7NgC

**QUESTIONS:** #:ticket:┃ticket or #:ticket:┃questions-about-scripts
